#include "Main.h"

int main()
{
	std::cout << "Hello World \n";
	//Ending the program
	std::cout << "Press enter to finish";
	getchar();
	return 0;
}